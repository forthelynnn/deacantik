export default function UGCGenerator(){
  return (
    <div style={{padding:20,color:'white'}}>
      <h1>UGC Outfit Generator</h1>
      <p>Full UI will be implemented here.</p>
    </div>
  )
}