import "../styles/globals.css";
import UGCGenerator from '../components/UGCGenerator'

export default function Home(){
  return <UGCGenerator/>
}